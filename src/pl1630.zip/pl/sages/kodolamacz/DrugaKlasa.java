package pl.sages.kodolamacz;

public class DrugaKlasa {

    public static void main(String[] args) {

    }

}

class TrzeciaKlasa {

}

class PiątaKlasa{

}
