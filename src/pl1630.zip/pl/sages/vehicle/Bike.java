package pl.sages.vehicle;

public class Bike {

    // dostep pakietowy
    // car wie, ze bike ma biegi, ale person juz nie
    int gears;

}
