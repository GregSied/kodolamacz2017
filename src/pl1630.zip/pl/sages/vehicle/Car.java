package pl.sages.vehicle;

public class Car {

    /**
     * liczba biegów
     * @author Bartek
     */
    public int gears = 4; // komentarz na koncu linii
    // int gear - ten kod nie dziala
    // marka i model auta
    public String model;

    public static void main(String[] args) {
        Bike bike = new Bike();
        //bike.gears;
    }

}
